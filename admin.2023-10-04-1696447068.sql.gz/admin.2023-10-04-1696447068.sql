-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: admin
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bien`
--

DROP TABLE IF EXISTS `bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_bien_id` int(11) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nbr_traveller` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_45EDC38695B4D7FA` (`type_bien_id`),
  CONSTRAINT `FK_45EDC38695B4D7FA` FOREIGN KEY (`type_bien_id`) REFERENCES `type_bien` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1645 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bien`
--

LOCK TABLES `bien` WRITE;
/*!40000 ALTER TABLE `bien` DISABLE KEYS */;
INSERT INTO `bien` VALUES (1353,136,'Très jolie mobile-home composé pour accueillir 3 personnes','/images/mobile-home-3.jpg',3,1521),(1354,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1521),(1355,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1521),(1356,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1521),(1357,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1525),(1358,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1525),(1359,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1528),(1360,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1528),(1361,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1529),(1362,136,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3,1530),(1363,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1531),(1364,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1531),(1365,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1531),(1366,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1531),(1367,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1531),(1368,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1538),(1369,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1538),(1370,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1538),(1371,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1539),(1372,137,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4,1540),(1373,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1541),(1374,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1542),(1375,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1543),(1376,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1544),(1377,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1545),(1378,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1546),(1379,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1547),(1380,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1548),(1381,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1549),(1382,138,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5,1542),(1383,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1384,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1385,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1386,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1387,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1388,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1389,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1390,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1391,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1392,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1393,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1394,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1395,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1396,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1397,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1398,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1399,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1400,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1401,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1402,139,'mobile-home pour 6 personnes','/images/mobile-home-6.jpg',6,0),(1403,140,'caravane pour 2 personnes','/images/caravane-2.jpg',2,0),(1404,140,'caravane pour 2 personnes','/images/caravane-2.jpg',2,0),(1405,140,'caravane pour 2 personnes','/images/caravane-2.jpg',2,0),(1406,141,'caravane pour 4 personnes','/images/caravane-4.jpg',4,0),(1407,141,'caravane pour 4 personnes','/images/caravane-4.jpg',4,0),(1408,141,'caravane pour 4 personnes','/images/caravane-4.jpg',4,0),(1409,141,'caravane pour 4 personnes','/images/caravane-4.jpg',4,0),(1410,142,'caravane pour 6 personnes','/images/caravane-6.jpg',6,0),(1411,142,'caravane pour 6 personnes','/images/caravane-6.jpg',6,0),(1412,142,'caravane pour 6 personnes','/images/caravane-6.jpg',6,0),(1413,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1414,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1415,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1416,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1417,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1418,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1419,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1420,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1421,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1422,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1423,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1424,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1425,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1426,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1427,143,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1,0),(1428,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1429,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1430,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1431,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1432,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1433,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1434,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1435,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1436,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1437,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1438,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1439,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1440,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1441,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1442,144,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2,0),(1643,139,'hghfghfghgf','mobile-home-6-651c540f769ff.webp',8,NULL),(1644,136,'gdfgfdgfd','mobilhome-651c5434ed06f.webp',3,NULL);
/*!40000 ALTER TABLE `bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20231002121642','2023-10-02 12:16:59',66),('DoctrineMigrations\\Version20231002154030','2023-10-02 15:41:05',39),('DoctrineMigrations\\Version20231002235835','2023-10-02 23:59:07',66),('DoctrineMigrations\\Version20231003103505','2023-10-03 17:16:23',65);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturation`
--

DROP TABLE IF EXISTS `facturation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fisrtname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `prix_total` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturation`
--

LOCK TABLES `facturation` WRITE;
/*!40000 ALTER TABLE `facturation` DISABLE KEYS */;
INSERT INTO `facturation` VALUES (12,'Honoré','Merle','emmanuelle.lebreton@cousin.net','0406701657','2024-08-10 00:00:00','2024-08-20 00:00:00',62800),(14,'Constance','Peron','blanchet.marcelle@pruvost.org','+33 (0)1 97 03 52 91','2024-08-25 00:00:00','2024-09-05 00:00:00',64530),(19,'Julie','Giraud','lucas.masson@club-internet.fr','08 06 28 91 61','2024-07-20 00:00:00','2024-07-30 00:00:00',68730),(20,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-01-01 00:00:00','2024-01-02 00:00:00',152730),(21,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-08-10 00:00:00','2024-08-15 00:00:00',10150),(22,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-08-30 00:00:00','2024-09-10 00:00:00',67530),(23,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-08-24 00:00:00','2024-09-10 00:00:00',108660),(24,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-08-05 00:00:00','2024-08-10 00:00:00',7950),(25,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-07-11 00:00:00','2024-07-14 00:00:00',6090),(26,'Denis','Pires','theophile86@bertin.com','+33 (0)3 20 39 46 71','2024-06-04 00:00:00','2024-06-20 00:00:00',78945);
/*!40000 ALTER TABLE `facturation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infrastructure`
--

DROP TABLE IF EXISTS `infrastructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infrastructure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infrastructure`
--

LOCK TABLES `infrastructure` WRITE;
/*!40000 ALTER TABLE `infrastructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `infrastructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `prix_total` int(11) NOT NULL,
  `nbr_enfant` int(11) NOT NULL,
  `nbr_adult` int(11) NOT NULL,
  `nbr_baby` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bien_id` int(11) NOT NULL,
  `acces_piscine` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_42C84955A76ED395` (`user_id`),
  KEY `IDX_42C84955BD95B80F` (`bien_id`),
  CONSTRAINT `FK_42C84955A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_42C84955BD95B80F` FOREIGN KEY (`bien_id`) REFERENCES `bien` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (14,'2024-08-10 00:00:00','2024-08-20 00:00:00',62800,1,2,0,1462,1357,NULL),(19,'2024-07-15 00:00:00','2024-07-25 00:00:00',58800,1,2,0,1501,1353,0),(20,'2024-01-01 00:00:00','2024-01-02 00:00:00',152730,3,2,0,1465,1373,1),(21,'2024-08-10 00:00:00','2024-08-15 00:00:00',10150,0,2,0,1465,1428,1),(22,'2024-08-30 00:00:00','2024-09-10 00:00:00',67530,2,2,0,1465,1363,1),(23,'2024-08-24 00:00:00','2024-09-10 00:00:00',108660,2,2,0,1465,1410,1),(24,'2024-08-05 00:00:00','2024-08-10 00:00:00',7950,0,1,0,1465,1413,1),(25,'2024-07-11 00:00:00','2024-07-14 00:00:00',6090,0,2,0,1465,1428,1),(26,'2024-06-04 00:00:00','2024-06-20 00:00:00',78945,0,2,0,1465,1403,1);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxe`
--

DROP TABLE IF EXISTS `taxe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxe`
--

LOCK TABLES `taxe` WRITE;
/*!40000 ALTER TABLE `taxe` DISABLE KEYS */;
INSERT INTO `taxe` VALUES (40,'Taxe de séjour - Enfant',35),(41,'Taxe de séjour - Adulte',60),(42,'Accès piscine - Enfant',100),(43,'Accès piscine - Adulte',150),(44,'Mobile-home 3 pers.',5000),(45,'Mobile-home 4 pers.',5400),(46,'Mobile-home 5 pers.',5700),(47,'Mobile-home 6-8 pers.',6400),(48,'Caravane 2 places',4500),(49,'Caravane 4 places',4800),(50,'Caravane 6 places',5400),(51,'Emplacement tente 8 m²',1200),(52,'Emplacement tente 12m²',1400);
/*!40000 ALTER TABLE `taxe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_bien`
--

DROP TABLE IF EXISTS `type_bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_bien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_bien`
--

LOCK TABLES `type_bien` WRITE;
/*!40000 ALTER TABLE `type_bien` DISABLE KEYS */;
INSERT INTO `type_bien` VALUES (136,'mobile-home-3',50),(137,'mobile-home-4',54),(138,'mobile-home-5',57),(139,'mobile-home-6',64),(140,'caravane-2',45),(141,'caravane-4',48),(142,'caravane-6',54),(143,'emplacement-1',12),(144,'emplacement-2',14);
/*!40000 ALTER TABLE `type_bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1551 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1460,'Émile','Mahe','admin@admin.com','$2y$13$8ABQzCCimGNZkh/HLcZueOQqFj0.xiFhnimajW7o4RPYNxqT/FTrC','+33 1 95 61 73 66','[\"ROLE_ADMIN\"]'),(1461,'Philippine','Masse','joseph.germain@bazin.fr','$2y$13$om9Y84Xzz6CgWvfffSFtlOxlTB/WI93IihT0NiX6fUk7vGUnxJhaq','+33 5 71 89 86 91','[\"ROLE_USER\"]'),(1462,'Honoré','Merle','emmanuelle.lebreton@cousin.net','$2y$13$Lyt9rqKgjBuQ7cziOczJfeMTQDSv0ul07xgIITKDn03NUZRxGyZou','0406701657','[\"ROLE_USER\"]'),(1463,'Emmanuel','Aubry','dominique.guerin@martel.fr','$2y$13$hntKVcsXFxPAtUmW8PC7Aey3dQ3NkEFs5Jlk8ALD4olWY/3lU1PM.','+33 1 95 27 03 65','[\"ROLE_USER\"]'),(1464,'Constance','Peron','blanchet.marcelle@pruvost.org','$2y$13$hwEVVHQjQqx1ioglJDvJkOejfTYYio09H29qv87OM7oknVCiEgHKS','+33 (0)1 97 03 52 91','[\"ROLE_USER\"]'),(1465,'Denis','Pires','theophile86@bertin.com','$2y$13$CHM6sXSeROl4kdQn2y95fOaQ6untqLJw1jSNUKOrRajZ9VEGXQbY.','+33 (0)3 20 39 46 71','[\"ROLE_USER\"]'),(1466,'Pierre','Marechal','hortense.marin@leconte.com','$2y$13$CGaXo2izug2aQHulJ1GTvuHyCMxCJAjA0YuCuF9eE10i8IYiCDEju','+33 (0)9 72 55 48 58','[\"ROLE_USER\"]'),(1467,'Emmanuel','Olivier','opineau@martel.com','$2y$13$Dstds8XC82EswxDz/WuEheMrVsg6bp5i8gAW1sEAObpEF/AuP69OG','0570873329','[\"ROLE_USER\"]'),(1468,'Noël','Mary','genevieve.morin@live.com','$2y$13$rWvlBZaOWdtw62Yphc1Fiucyqo2WwxijQbhqRgXYduSFlYipe4SGS','+33 2 43 50 81 90','[\"ROLE_USER\"]'),(1469,'Zoé','Joseph','emary@renaud.fr','$2y$13$l8rDDzdsXMHElfM.GRaO2uPK0HwCDAqvg7NZmmXL8OmHuU5QerRbO','0984249744','[\"ROLE_USER\"]'),(1470,'Bernadette','Delannoy','michaud.hugues@remy.org','$2y$13$YJz.l3uwACrwGZX8jkwXEep67OeYitfFhEe4jC7Eh1WgR6lhCbiYG','+33 (0)1 30 55 75 99','[\"ROLE_USER\"]'),(1471,'Alexandrie','Remy','emile98@hamon.com','$2y$13$AX5ObxvBn0XbMPXIgHu1Eewp5A9cuzMZE3f055p9X0hTcu/4bzfFa','+33 8 45 86 44 56','[\"ROLE_USER\"]'),(1472,'Clémence','Petitjean','abarbe@imbert.com','$2y$13$yg17p70MVvc3DLTShxBl1uxM4rSyx.Ea01/F69nxwLEPWk1R3DC8.','+33 (0)9 70 74 33 36','[\"ROLE_USER\"]'),(1473,'Roger','Vallet','bertrand.lemaire@guillon.com','$2y$13$C.uWl/ISOebumPgLrfSY0O477hA7OAJZ1byWffkz1IgVL68sEw.xS','+33 1 42 68 66 46','[\"ROLE_USER\"]'),(1474,'Yves','Carlier','lefort.zacharie@free.fr','$2y$13$WiNSDW0IKzMoquz9E5fiOuhQuhynUrdvOVxo88k4HY3jIdIZTkplO','+33 1 30 00 71 40','[\"ROLE_USER\"]'),(1475,'Denis','Delorme','christiane.philippe@yahoo.fr','$2y$13$aBfm0Lhk.vUyNwtQXg2GeucMuXPve3Cx/ZXJr7rsO2fIga6hJnhVS','0538753772','[\"ROLE_USER\"]'),(1476,'Manon','Chauveau','rene.francois@sauvage.fr','$2y$13$i7qp/MaXdyjH4pDosn3Qwuxb7pi1aJi3NzVt8JgZoJtw.eHb6sAom','08 86 28 67 51','[\"ROLE_USER\"]'),(1477,'Gabrielle','Renard','lchevalier@didier.org','$2y$13$.0NsIKWABMCSR2pU9vLus.o/bO9jIYPkweR8TYpBZPHR3eDetUg9u','+33 (0)5 95 85 28 81','[\"ROLE_USER\"]'),(1478,'Daniel','Ferreira','jlevy@bouygtel.fr','$2y$13$lfkgBA9AKdUxQ2cndYbH9OJT/VRbbTLCdUC0IZ8uyoqSIWwq2i5uG','+33 (0)1 19 38 72 24','[\"ROLE_USER\"]'),(1479,'Stéphane','Pasquier','martins.valentine@fernandez.net','$2y$13$wCIAQWVI3/iLSvx8IZJBOe0/ru1flCYBr4z2SZRAE0KvRn8.3Tb62','+33 5 48 76 71 81','[\"ROLE_USER\"]'),(1480,'Guillaume','Briand','zroche@barthelemy.fr','$2y$13$MQmA1HIzb9j59Gt94.SqNOKPLQ3Gsf13oXoCiX/xz6eWwo0.iGXWK','0367810155','[\"ROLE_USER\"]'),(1481,'Gabrielle','Guyot','theophile32@free.fr','$2y$13$ty50tJEhdgTnUupYjXikAOpdvbgIY9mJK8jvKEeiGvMQOW6t1i/Py','+33 (0)9 33 97 61 44','[\"ROLE_USER\"]'),(1482,'François','Bousquet','amelie.collet@orange.fr','$2y$13$8Ex/xwVwlMHwUh4/CbNMoOzbWD9PahUYexyMGcsR1PtCzkijziHOK','0481034885','[\"ROLE_USER\"]'),(1483,'Marianne','David','klein.thierry@charrier.fr','$2y$13$1lUTkbpmORc0TNc1SNi94eohc1a1QUG6K/ksB/q.0V5yhl3fdy.Sm','+33 (0)1 78 92 34 97','[\"ROLE_USER\"]'),(1484,'Victor','Gimenez','cecile02@voila.fr','$2y$13$8m0BVUqyv47KG1eBLfkIjO8uLZ2ZzwN3WPg4Zhb7fxP.TjsUnZBdi','+33 (0)1 81 66 80 15','[\"ROLE_USER\"]'),(1485,'Richard','Fischer','ubigot@tiscali.fr','$2y$13$ZPrCg4Xwh1.T7wVz.fhDaeYskoIlNuQG912o0hlWaCCmZvWcpgh52','0289008048','[\"ROLE_USER\"]'),(1486,'Stéphane','Techer','leclercq.cecile@begue.org','$2y$13$f1KWD3XSJaHv61QCE7GGdeGtsUOe0FqT///KRC29oF0TbX7PrSI/u','+33 (0)1 11 70 71 10','[\"ROLE_USER\"]'),(1487,'Jean','Leroux','josette.renard@guyot.net','$2y$13$Gpb6G/sfm7cfg5XtsEfIF.RDBAsIDnQD9y5X5G0M8J8WGRVNTyTG6','+33 (0)4 11 02 08 18','[\"ROLE_USER\"]'),(1488,'Élodie','Meyer','parent.marie@bouygtel.fr','$2y$13$yd2mzyu5y95gHX5xpbq/YOZICgbPXoryvhEEvhAGj93VkBnkOrQ9S','+33 (0)6 89 90 88 97','[\"ROLE_USER\"]'),(1489,'François','Vasseur','valette.alphonse@camus.fr','$2y$13$KzkUd//mt8l6tfIYrsmYNundAsO3.My8FcjUsRQ4nKFPzEzvopy1C','+33 6 92 81 35 53','[\"ROLE_USER\"]'),(1490,'Éric','Baudry','david31@tele2.fr','$2y$13$QPAyrEjSvspayVxyvyIYl.3vCFCJ1SaYtIncSa1Op/W6NCZSx0Spa','+33 1 44 13 13 66','[\"ROLE_USER\"]'),(1491,'Dorothée','Clerc','roy.roland@laposte.net','$2y$13$GBTeb3pQf/xjcG1r77YhUOieHzRoUT66kYgrcEtBNPwC6jpjeco4u','0797835075','[\"ROLE_USER\"]'),(1492,'Laurent','Peron','bodin.jeannine@guillon.com','$2y$13$BzcTU432dICDU1q56eLZSuA6BRJAjz3jnvOaql6GH03LzHq.LHRfi','+33 6 04 37 35 75','[\"ROLE_USER\"]'),(1493,'Marie','Payet','bertrand.bonnet@club-internet.fr','$2y$13$yGqSuXZ4wxb2sOzhe.CzheuJkFvIQq/DlSfESXfycpelI8XNa56s.','0530067887','[\"ROLE_USER\"]'),(1494,'Guillaume','Bazin','aurore.payet@besnard.com','$2y$13$WO.DFmYuvvqObxgBRW15S.NrQ.V1boNwW5KoxEZNZASJiRJYPKutq','+33 5 07 14 43 23','[\"ROLE_USER\"]'),(1495,'Benoît','Picard','texier.alphonse@gmail.com','$2y$13$qSYfQmWfeVmsuFDOUlseE.WNfUq4HES4.QL4.IVabpAbTtM3ejG0e','+33 4 22 31 45 85','[\"ROLE_USER\"]'),(1496,'Guy','Lebrun','margot.fouquet@wanadoo.fr','$2y$13$.eapAUUM.LD3TFqnpKllXOcRGvq3H3MIFYwOkKF0wXyZnwMOKtAJW','0237010628','[\"ROLE_USER\"]'),(1497,'Susanne','De Oliveira','alain96@yahoo.fr','$2y$13$Uz3r.A6b8qrYO3t4XjKsburNQ0sLP9rleCB/OisWglxhZO8CrleOa','+33 1 19 82 22 27','[\"ROLE_USER\"]'),(1498,'Chantal','Georges','paubert@wagner.fr','$2y$13$/Kc26bNQW9YnEWBEbqIPdOzFHSwQcQ6dWQoXJG1/Y7nk60NUqZnrq','+33 (0)2 72 83 03 49','[\"ROLE_USER\"]'),(1499,'Élisabeth','Richard','dleclerc@morin.net','$2y$13$7fF1TaljeTZagbF6GWhAdeiiNgNBhwXR51kEopZbmoq9I4PKb/8Zq','+33 (0)2 44 67 81 95','[\"ROLE_USER\"]'),(1500,'Gilbert','Delahaye','zantoine@pelletier.org','$2y$13$Uk6PrKNWCZVjTeKRNgn/tuRahU.4JJQ7HyPMGneiFG8/pl8qZgyRi','+33 6 37 95 91 20','[\"ROLE_USER\"]'),(1501,'Julie','Giraud','lucas.masson@club-internet.fr','$2y$13$Nylx9g6s3JwPLiXWIG2.JOMJHSI8RzoUMcxaNJo.ysQy0GGnUHP2C','08 06 28 91 61','[\"ROLE_USER\"]'),(1502,'Rémy','Thierry','uhenry@wanadoo.fr','$2y$13$8vBgc84oveg9Ba4v0ChQLOHaJfu7c7ZSF/2gEyrQEgWCM36KOPzQy','02 35 35 65 54','[\"ROLE_USER\"]'),(1503,'Michelle','Chauvet','dominique.marion@ledoux.com','$2y$13$LNw7RkdMJFl.f.F.sn4ecuJrMISbJCcxArk4P6lXDEkMliST3FjKa','0491351178','[\"ROLE_USER\"]'),(1504,'Nicolas','Berger','langlois.aurelie@klein.com','$2y$13$jVIkdiFDADtIOWhMmDF8FOijnfjzYuuyX0Kxmg.fLuNUYwCgWNTqq','+33 2 36 72 09 84','[\"ROLE_USER\"]'),(1505,'Philippine','Descamps','jklein@orange.fr','$2y$13$DtCf0n/6IW4HFP/5jYb3.ezfMTHLpJAXiLqWCl48txBkkqkutMCxC','09 43 41 83 52','[\"ROLE_USER\"]'),(1506,'Margot','Hebert','honore94@ifrance.com','$2y$13$2sfSUVvZDyFGTywLCpZQcuV0unDeQCghQldGmfORb.D4fZUYyCYyS','0869734143','[\"ROLE_USER\"]'),(1507,'Victor','Legros','julien46@gaillard.fr','$2y$13$xUoizh2fZFxQgsGwFtS3a.F0bwn8XCUOMhdwpjxlr571mRhz7TuRS','0288435791','[\"ROLE_USER\"]'),(1508,'Amélie','Guyon','rperon@sfr.fr','$2y$13$LMkzBv8CYWIBFuuWqHaxQ.L08RcHIh9C5Rh8ZM1TJPjdOeA/GmnXG','01 85 55 84 53','[\"ROLE_USER\"]'),(1509,'Élise','Joubert','leblanc.corinne@gallet.fr','$2y$13$RVPHVlSBK5ne/HNaIC5ap.E2zTlUksaWTcm9rNIIW1g7GZFY4xOSi','0944559354','[\"ROLE_USER\"]'),(1510,'Margot','Meunier','francois.roger@noos.fr','$2y$13$T7jsWU5mV7bGm4617PdQYuP6ebHDNsWWRxHSLS6fKB8mUl9eBSmeW','01 76 42 56 05','[\"ROLE_USER\"]'),(1511,'Margaud','Blin','aboulanger@wanadoo.fr','$2y$13$4NNrxr.6nTvV64abFvBtBOnCE0NPRIZXKcmV7H9X9ZSLOJrWFRBUm','+33 8 36 82 27 10','[\"ROLE_USER\"]'),(1512,'Étienne','Dupuis','thierry30@bouygtel.fr','$2y$13$GAPmW3ifWkUqRc8iltnn5evA/ilmHSjqIkWx1vanWtWboAaVwJ5vy','0764338210','[\"ROLE_USER\"]'),(1513,'Gilbert','Pereira','delorme.lucy@gmail.com','$2y$13$Eyb/nPsghztAtIxOccX56OHQeUMrDsR7iroNXcU9BMgLYBMOzvtbi','+33 7 26 26 16 28','[\"ROLE_USER\"]'),(1514,'Jean','Collin','zleclercq@joseph.fr','$2y$13$HbtEA/GEQlI5yt2M.thbVejO4CH0v1Tl9RK0OSP64aZY5z4uT2sQO','+33 6 33 08 16 57','[\"ROLE_USER\"]'),(1515,'Bernard','Mallet','tristan.gregoire@live.com','$2y$13$DbFE8l17wK21rp4HK04JIuNUP6jqPdXwk4PvwLMEmzUAu9JJM586K','0129957680','[\"ROLE_USER\"]'),(1516,'Virginie','Coste','denis.luc@delorme.fr','$2y$13$7W.cAxniR1fiSJ6PR8bLqed99JFR6tm8jCDSn0r/9KAQrtPYwVTTe','+33 (0)1 07 86 26 11','[\"ROLE_USER\"]'),(1517,'Lucas','Rousseau','qguillou@guyot.fr','$2y$13$otSuNzA7tzZgfyavgDQtt.BlBsp88cEZ07wTAe3fy2iioxe.cqNPe','0670897878','[\"ROLE_USER\"]'),(1518,'Noémi','Marchal','delorme.antoine@tele2.fr','$2y$13$jJMP07IueiP6yLn.MO.QX.98G0a2MFE7NLDuSdmaRr.LZe4AYnTU2','0938906032','[\"ROLE_USER\"]'),(1519,'Claude','Lemaitre','colette70@laposte.net','$2y$13$EKvZKhcXWf4U9TDan5MgHenX3iakWFqIHCBxU1q0EwAJ8laZ/NtTm','+33 (0)8 50 89 91 44','[\"ROLE_USER\"]'),(1520,'Cécile','Chartier','pages.roland@reynaud.com','$2y$13$r1/Hk0qVE/7rXbbB5z4KG.CL44eI.c5f0rAWdRzElFvFehUNQAMhW','06 37 81 37 51','[\"ROLE_USER\"]'),(1521,'Augustin','Langlois','sebastien41@leleu.com','$2y$13$LKVEdX4IwchvUfT3KMgj1ufztzrwAdhHOJ7wolhTJ8aNQZlv0hegO','02 25 73 61 24','[\"ROLE_OWNER\"]'),(1522,'Jacques','Nguyen','fribeiro@yahoo.fr','$2y$13$F2DYjKcLMmAjhTL57/iGz.cjJlk97KWqn7lxrO8Px9vot3Wytd77e','07 17 56 12 93','[\"ROLE_OWNER\"]'),(1523,'Gérard','Collin','igosselin@dbmail.com','$2y$13$ypAseWgL6GERMJhlO6WtZ.Mp1UuKsxKmZXQ8FHXdoOHW6bv9NZIUK','+33 (0)6 66 50 85 04','[\"ROLE_OWNER\"]'),(1524,'Brigitte','Bodin','helene12@laposte.net','$2y$13$X2lm9FC/5m2lFekudP0kZef2LMiC20YdQoh6GKQhQFsgCH0MRE4lW','08 11 05 23 58','[\"ROLE_OWNER\"]'),(1525,'Hélène','Imbert','xpetitjean@dbmail.com','$2y$13$9Ka/LBqm7aUdGlDxQIKgheWG1waYMVlgsh2aWHIiK66hO2cvnEKnS','+33 5 74 49 75 59','[\"ROLE_OWNER\"]'),(1526,'Louis','Grenier','anne92@samson.fr','$2y$13$wSx1MdSirgkQ1DVtksktzu3n6K1QDh9EkZQB2bpCnDuswHatv7nOa','+33 1 50 77 88 53','[\"ROLE_OWNER\"]'),(1527,'Margaux','Richard','laure.jean@live.com','$2y$13$moyuDz.T53XYywAUCzB8C.F9e5S/2.25gACJQnWG5wVX2vPwh7kRu','05 63 66 26 38','[\"ROLE_OWNER\"]'),(1528,'Adèle','Robert','vmary@orange.fr','$2y$13$gbpoGuBIIZUAgJTshH.nQ.GkVyDylVbIDL3bZIJPZ8LMZadRSBWH2','0986504012','[\"ROLE_OWNER\"]'),(1529,'Stéphane','Hamel','antoinette93@laposte.net','$2y$13$Ii.Jug6NQ56Oby/0bjnR4uR9/nGh2zow1qqxMRpThMR7wsPlvT0IG','+33 4 26 76 76 90','[\"ROLE_OWNER\"]'),(1530,'Alain','Lemaire','auguste90@wanadoo.fr','$2y$13$4n6PuQL6ShTGqgImrUEuy.FaSyw4IGroopQVCytXI3i5Ly79EAMnm','+33 1 23 59 85 17','[\"ROLE_OWNER\"]'),(1531,'Marc','Raymond','margaux09@collet.fr','$2y$13$xgX01COPcBrW64/zWvI1u.vl4UIX31bAtzgGZKdvyyb.Xze49a.8e','+33 (0)6 10 68 77 55','[\"ROLE_OWNER\"]'),(1532,'Valentine','Fouquet','kauger@tanguy.fr','$2y$13$wqFPbYUI/wwaanir4VuddO2un9.1alPdNMM2jRVLi52bKSiMUp8hy','+33 (0)6 04 93 09 69','[\"ROLE_OWNER\"]'),(1533,'Aurore','Blin','thomas.philippe@free.fr','$2y$13$PjJbitoIyVFCMUy/CjdWJuIT0.yfB36MTLOl8atOlYosTZSnRanVS','+33 (0)2 77 51 60 27','[\"ROLE_OWNER\"]'),(1534,'Nicolas','Gallet','bertrand11@hotmail.fr','$2y$13$mPcn9WbmFfQwsKIcVk5HG.fp0.x1Vx6uN0Qk9hL38IQiBetXfcWqa','0581858919','[\"ROLE_OWNER\"]'),(1535,'Philippe','Chauveau','francois.descamps@morvan.net','$2y$13$tqKmeX4dy9GBGYdLlL0g1uf2O3Oy08x54X.o8G6CufEoCMQircdu2','+33 (0)2 77 73 85 28','[\"ROLE_OWNER\"]'),(1536,'Dominique','Menard','ldasilva@blin.com','$2y$13$9YCDqeB/oU9zv4mVY1TpaOrJ9Y9Sqo52Mh/3q.bcUs1xJL6DDyW86','0724018151','[\"ROLE_OWNER\"]'),(1537,'Isaac','Hoarau','laporte.charles@launay.fr','$2y$13$VMcqp54zLGm1gexxNWzBwu6vL.7fo9BivpXf2kWgpCMSw5s/.C2Cy','01 08 10 96 55','[\"ROLE_OWNER\"]'),(1538,'Antoinette','Mercier','margot23@free.fr','$2y$13$Ges3XhHlK0oPz98ZCAJkKew9WczkQunyidBedytw3FCw9ocmS2McW','+33 1 21 82 57 09','[\"ROLE_OWNER\"]'),(1539,'Roland','Chartier','xmichaud@live.com','$2y$13$U2pb5pAjNoZ9PShC3qVp.erukDl1tXESbf3yzfVjNaXF1nwgKmzAq','+33 7 53 74 04 53','[\"ROLE_OWNER\"]'),(1540,'Margaux','Reynaud','jeannine.fischer@peltier.fr','$2y$13$13JV7SgbgWQ8pfxCAT8ko.McTCeVJ2LgMLDgGGgcepopNGdnnGGD6','08 15 88 53 23','[\"ROLE_OWNER\"]'),(1541,'Patrick','Fischer','tcollet@chretien.com','$2y$13$wR2QXHg6bF6Ukwqae3tbheTuV54qt3mICjWPFWRz8PxGgQZkN13h2','+33 1 54 92 64 78','[\"ROLE_OWNER\"]'),(1542,'Olivier','Durand','penelope.raynaud@wanadoo.fr','$2y$13$rulWL54d994ux4rRLauZ6uF.69zoRpzU0sKbiZpactVdoPsKXqm6u','0834241200','[\"ROLE_OWNER\"]'),(1543,'Maggie','Pasquier','frederic67@rodriguez.com','$2y$13$4gYmiZAyj/2JjgD9Nb/VIeG8l1I2L9UcAwZpJRprP0kaVoc6xR42C','01 63 76 23 23','[\"ROLE_OWNER\"]'),(1544,'Alain','Delaunay','elise.julien@gmail.com','$2y$13$yDIJbA4WiSRVjyrQhABnNujeCtFljVVN8ttLcBi9ZfW83dfVmFdvm','+33 (0)1 76 03 07 09','[\"ROLE_OWNER\"]'),(1545,'Audrey','Fontaine','olivie75@yahoo.fr','$2y$13$daczF8dTdCAEIS8uIt/rhuEUVe6zLT1be5qOWyWI5BVjzZ1fGAdbq','03 71 57 31 29','[\"ROLE_OWNER\"]'),(1546,'Michèle','Morvan','hugues.launay@rey.fr','$2y$13$sO2X/JdpEy/Gqtq0Wu4UOuW1KE.HW32Vl/AwVXIhep2/ev/ZOWe2a','0620340569','[\"ROLE_OWNER\"]'),(1547,'Guillaume','Dijoux','barbe.david@giraud.net','$2y$13$yGdKtJ60iQKpZGE/BPN.QOgK92LsJQyEe1/xo7WW.tis3R0CbderS','0439062432','[\"ROLE_OWNER\"]'),(1548,'André','Da Costa','brigitte.dubois@lacombe.org','$2y$13$8HTAfmKgeJT9CXoD1lTdn.ySjqN3UQ5vjwl9qoBVvG2eCY/3GhcQ.','07 61 76 03 25','[\"ROLE_OWNER\"]'),(1549,'Alexandrie','Mahe','pottier.marc@free.fr','$2y$13$4vHC7Mt7tKfxYgoZqHUgZuESbuxE7lHNDaIeMe44DXpbqurYrDbNa','0224782481','[\"ROLE_OWNER\"]'),(1550,'Guillaume','Turpin','dominique61@gay.fr','$2y$13$LOdo1fi3KhDGGm2wkW3Vd.jpNnFfj35VbgJO.uTSWovjG7MOMCpc2','+33 9 42 95 04 02','[\"ROLE_OWNER\"]');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-04 19:17:48
