-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: admin
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bien`
--

DROP TABLE IF EXISTS `bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_bien_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nbr_traveller` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_45EDC38695B4D7FA` (`type_bien_id`),
  KEY `IDX_45EDC386A76ED395` (`user_id`),
  CONSTRAINT `FK_45EDC38695B4D7FA` FOREIGN KEY (`type_bien_id`) REFERENCES `type_bien` (`id`),
  CONSTRAINT `FK_45EDC386A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bien`
--

LOCK TABLES `bien` WRITE;
/*!40000 ALTER TABLE `bien` DISABLE KEYS */;
INSERT INTO `bien` VALUES (1,1,81,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(2,1,85,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(3,1,74,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(4,1,87,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(5,1,62,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(6,1,69,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(7,1,71,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(8,1,84,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(9,1,82,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(10,1,75,'mobile-home pour 3 personnes','/images/mobile-home-3.jpg',3),(11,2,69,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(12,2,89,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(13,2,84,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(14,2,77,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(15,2,90,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(16,2,74,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(17,2,91,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(18,2,71,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(19,2,85,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(20,2,62,'mobile-home pour 4 personnes','/images/mobile-home-4.jpg',4),(21,3,90,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(22,3,76,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(23,3,79,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(24,3,63,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(25,3,89,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(26,3,82,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(27,3,71,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(28,3,87,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(29,3,73,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(30,3,76,'mobile-home pour 5 personnes','/images/mobile-home-5.jpg',5),(31,4,83,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(32,4,77,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(33,4,85,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(34,4,64,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(35,4,82,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(36,4,63,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(37,4,68,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(38,4,73,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(39,4,70,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(40,4,90,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(41,4,65,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(42,4,70,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(43,4,85,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(44,4,67,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(45,4,79,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(46,4,76,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(47,4,72,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(48,4,70,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(49,4,63,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(50,4,72,'mobile-home pour 8 personnes','/images/mobile-home-8.jpg',8),(51,5,NULL,'caravane pour 2 personnes','/images/caravane-2.jpg',2),(52,5,NULL,'caravane pour 2 personnes','/images/caravane-2.jpg',2),(53,5,NULL,'caravane pour 2 personnes','/images/caravane-2.jpg',2),(54,6,NULL,'caravane pour 4 personnes','/images/caravane-4.jpg',4),(55,6,NULL,'caravane pour 4 personnes','/images/caravane-4.jpg',4),(56,6,NULL,'caravane pour 4 personnes','/images/caravane-4.jpg',4),(57,6,NULL,'caravane pour 4 personnes','/images/caravane-4.jpg',4),(58,7,NULL,'caravane pour 6 personnes','/images/caravane-6.jpg',6),(59,7,NULL,'caravane pour 6 personnes','/images/caravane-6.jpg',6),(60,7,NULL,'caravane pour 6 personnes','/images/caravane-6.jpg',6),(61,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(62,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(63,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(64,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(65,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(66,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(67,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(68,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(69,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(70,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(71,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(72,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(73,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(74,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(75,8,NULL,'emplacement pour 1 personnes','/images/emplacement-1.jpg',1),(76,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(77,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(78,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(79,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(80,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(81,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(82,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(83,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(84,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(85,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(86,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(87,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(88,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(89,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2),(90,9,NULL,'emplacement pour 2 personnes','/images/emplacement-2.jpg',2);
/*!40000 ALTER TABLE `bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20231107213342','2023-11-07 21:34:10',2),('DoctrineMigrations\\Version20231107214256','2023-11-07 21:43:06',96);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturation`
--

DROP TABLE IF EXISTS `facturation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fisrtname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `prix_total` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturation`
--

LOCK TABLES `facturation` WRITE;
/*!40000 ALTER TABLE `facturation` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infrastructure`
--

DROP TABLE IF EXISTS `infrastructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infrastructure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infrastructure`
--

LOCK TABLES `infrastructure` WRITE;
/*!40000 ALTER TABLE `infrastructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `infrastructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bien_id` int(11) NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `prix_total` int(11) NOT NULL,
  `nbr_enfant` int(11) NOT NULL,
  `nbr_adult` int(11) NOT NULL,
  `nbr_baby` int(11) NOT NULL,
  `acces_piscine` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_42C84955A76ED395` (`user_id`),
  KEY `IDX_42C84955BD95B80F` (`bien_id`),
  CONSTRAINT `FK_42C84955A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_42C84955BD95B80F` FOREIGN KEY (`bien_id`) REFERENCES `bien` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxe`
--

DROP TABLE IF EXISTS `taxe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxe`
--

LOCK TABLES `taxe` WRITE;
/*!40000 ALTER TABLE `taxe` DISABLE KEYS */;
INSERT INTO `taxe` VALUES (1,'Taxe de séjour - Enfant',35),(2,'Taxe de séjour - Adulte',60),(3,'Accès piscine - Enfant',100),(4,'Accès piscine - Adulte',150),(5,'Mobile-home 3 pers.',5000),(6,'Mobile-home 4 pers.',5400),(7,'Mobile-home 5 pers.',5700),(8,'Mobile-home 6-8 pers.',6400),(9,'Caravane 2 places',4500),(10,'Caravane 4 places',4800),(11,'Caravane 6 places',5400),(12,'Emplacement tente 8 m²',1200),(13,'Emplacement tente 12m²',1400);
/*!40000 ALTER TABLE `taxe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_bien`
--

DROP TABLE IF EXISTS `type_bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_bien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_bien`
--

LOCK TABLES `type_bien` WRITE;
/*!40000 ALTER TABLE `type_bien` DISABLE KEYS */;
INSERT INTO `type_bien` VALUES (1,'mobile-home-3',50),(2,'mobile-home-4',54),(3,'mobile-home-5',57),(4,'mobile-home-8',64),(5,'caravane-2',45),(6,'caravane-4',48),(7,'caravane-6',54),(8,'emplacement-1',12),(9,'emplacement-2',14);
/*!40000 ALTER TABLE `type_bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Marthe','Barre','admin@admin.com','[\"ROLE_ADMIN\"]','$2y$13$UY.6bpLHpvaLPZHvqOOSR.KNhCXk79Vh58gGdrGhr.qhJ1xPO8WXi','01 10 42 08 93'),(2,'Clémence','Salmon','benoit.blanc@bouygtel.fr','[\"ROLE_USER\"]','$2y$13$GY3hBGQxxHeUdx.ZPhPrL.UOuRsUWT7UfRcGllvh.TjySqXgciwzG','02 94 00 68 92'),(3,'Gilbert','Bouchet','maggie50@free.fr','[\"ROLE_USER\"]','$2y$13$3XVok2KJEeBt4c5BpYIbCuedK.0A0EP0uQNcZMUlTXTME9dsGx91.','+33 (0)3 38 94 19 35'),(4,'Anaïs','Lemoine','helene30@bouygtel.fr','[\"ROLE_USER\"]','$2y$13$6rMNGxhfzoYTnMAJcAmzxO2ApKh0cuM85FD6KodzTDeYvJUfF5RA6','+33 (0)8 95 85 72 57'),(5,'Julien','Caron','loiseau.agathe@ifrance.com','[\"ROLE_USER\"]','$2y$13$PIejE5euPPHQ/oeEK8g/pOqDqBP2BEeTP2YSKwfLA.dL7wvnopJGq','09 41 46 90 07'),(6,'Benoît','Ollivier','suzanne62@leroy.com','[\"ROLE_USER\"]','$2y$13$bW6h/vZ3GXZr1jhjrrPNE.u7xWzOPOTgMnQxjX3CCJQZ4cJOd6mFy','0530479859'),(7,'Océane','Begue','aollivier@ifrance.com','[\"ROLE_USER\"]','$2y$13$H3eYWTUWl6ADCcqMVp9ihuloN8lymYpCIuhNYS9MQ4MFXjKLl6ska','+33 3 41 14 16 24'),(8,'Alain','Chauveau','valerie34@bonnin.com','[\"ROLE_USER\"]','$2y$13$rgH.1sP3qo7hf9EdIub8Duym3aPnjysa1Vg/fAU/kTmbiA0jImTQq','0180245462'),(9,'Julien','Gimenez','ycollet@gerard.com','[\"ROLE_USER\"]','$2y$13$YpFHhZIy5tBYuIpwusr6KeSqyJGBklgMUljr78xdFd8vD5rBzalZe','+33 1 58 54 92 22'),(10,'Léon','Faivre','brunet.robert@pichon.com','[\"ROLE_USER\"]','$2y$13$g4REysBTGZkylVxCpu7e.ONmWT9FSZhs5YB8XkYSHJFyIIbXNdAF.','0901709455'),(11,'Gabrielle','Lelievre','deoliveira.guy@morin.com','[\"ROLE_USER\"]','$2y$13$JHK6MBs/WhYRgPaNfWxGO.DKqmaCNn8JGqwFtqTW7tYmJ8Sr/9cuu','0939624028'),(12,'Joséphine','David','aime88@imbert.com','[\"ROLE_USER\"]','$2y$13$gc9qu/7tjMNtmEYamLycLuVoUCqvbpsFwLUtbsYo5JT9fTkzvjKSO','04 50 40 38 69'),(13,'Nathalie','Leveque','gautier.dominique@philippe.com','[\"ROLE_USER\"]','$2y$13$tGfU4oq4uspc72M3n3lWyuuydOPJ/JZgJ4KyHFm.r.Gh8IOZIpEpK','04 51 78 87 79'),(14,'Julien','Rey','caron.daniel@noos.fr','[\"ROLE_USER\"]','$2y$13$m70VN9udqc6/beEXxXHqQei0x7EOmEXfW6aW0tT6RAhYeMabp4FXC','02 38 05 74 55'),(15,'Julie','De Sousa','aurelie97@gomes.fr','[\"ROLE_USER\"]','$2y$13$s1QDzq7nTI5mlP.OF3t86uzjvDFcqkvQvuG.4zSebcLRfyMRDkB6i','+33 (0)6 93 50 69 77'),(16,'Gabriel','Guyon','henri64@francois.com','[\"ROLE_USER\"]','$2y$13$H6bSryGY8EYJ/n0OwzC7.uZGaKoRfQDwzGLSLEaLvWSBOdkMx07OK','0149840785'),(17,'Maryse','Dupuy','dominique08@noos.fr','[\"ROLE_USER\"]','$2y$13$q68VpRSIk.LQ2wvndd5.SeMguYdjtxaKKNwodRsUNtrx3hW5lZ40u','02 72 59 09 56'),(18,'Alexandre','Camus','rolland.stephanie@live.com','[\"ROLE_USER\"]','$2y$13$naw6eBX13Cp/xpV5VtHFs.w.LVDzAZvaz/MuC8BiRhclOSQhVataK','04 18 52 82 79'),(19,'Laure','Humbert','marine51@lemaire.com','[\"ROLE_USER\"]','$2y$13$EJBP2oF3bex.AG/NJHHYbOqk1QBDS4MM87IsaUD65SxM/QpnIdvmu','+33 (0)3 34 91 62 32'),(20,'Lucy','Buisson','pires.aurelie@michaud.net','[\"ROLE_USER\"]','$2y$13$oiME8MRC7K3m0shexA2JQumzZNqc7iGzgXg4UJksT8a3cSU1rv/U.','0535973487'),(21,'Frédérique','Gautier','josette.lelievre@noos.fr','[\"ROLE_USER\"]','$2y$13$mxfKvAnukC9zkghy5Vjnce1/nxXX0ejjEhTudYGTlqCPMzhbn5nmO','0219768009'),(22,'Zoé','Nguyen','bailly.benoit@thibault.fr','[\"ROLE_USER\"]','$2y$13$Yo9ig/L5hVE3F1em94ys2uUBQanPKqXp1VtcdtZA5m4wnnLadvrRS','+33 2 06 44 60 31'),(23,'Margaret','Arnaud','manon.rousseau@charpentier.net','[\"ROLE_USER\"]','$2y$13$elShGnfOfARoV3SUzCwJdu3PhNL5MM9rli2g.UjCL5JgEPxrDpZIy','+33 9 42 85 55 75'),(24,'Benoît','Alves','madeleine75@wanadoo.fr','[\"ROLE_USER\"]','$2y$13$PWQLa.ywPgmvbZNIA9.vrOzThTIqSg6kkOgPgbTuW9HDA3TADBdKq','+33 1 09 14 30 44'),(25,'Martine','Cousin','maurice99@voila.fr','[\"ROLE_USER\"]','$2y$13$oufaiX/32SXsdhNcx2iCD.XLAGSPzq5N7y8DiU9W22Qv.ac1k8UgC','+33 9 14 47 64 72'),(26,'Corinne','Deschamps','bourdon.edouard@sfr.fr','[\"ROLE_USER\"]','$2y$13$Vd3qAaIZX4S3N.X1.gB/mOoWzP8qCf0.ulz5qcKbnaTdGcWU5BlyK','0153099293'),(27,'Paul','Leconte','joubert.emmanuel@sfr.fr','[\"ROLE_USER\"]','$2y$13$ghuVtnu58kxCT0JaE9fO9.P1TwQ0ziSzQ5.OPsW7LNp8YA63laqZq','08 99 73 27 95'),(28,'Corinne','Thomas','adam.marcel@meyer.com','[\"ROLE_USER\"]','$2y$13$dNgkFoVb6nri.dlQMpkf3OpnvB9w/p2wKvLvP3U64anACcfPjVTzW','+33 (0)2 31 82 11 62'),(29,'Georges','Tessier','luc.dumont@hotmail.fr','[\"ROLE_USER\"]','$2y$13$IxD/T..INRF.R06pgOXQfuzgPjo0WBvD5nFyHn9Jevx1ByPt92KC.','+33 5 84 87 13 18'),(30,'Célina','Bouvet','genevieve.parent@wanadoo.fr','[\"ROLE_USER\"]','$2y$13$2SCyDhFfC7Tp8FenqquWqujxPovIyiWIpiOnArNbtpZkhSrGqX.7C','+33 5 66 66 53 42'),(31,'Xavier','Briand','yfrancois@laporte.com','[\"ROLE_USER\"]','$2y$13$.9Um7VtlJ9hyRrlWxcoWduM3TXaVrzShJ9FXWLboGbu1rOD4cIszW','01 76 09 74 93'),(32,'Hortense','Goncalves','imuller@dbmail.com','[\"ROLE_USER\"]','$2y$13$FdlXxe25WKic.Ms3NIK10e3LpLvPfFmJOWu3quSr16PXo2AN.Kyti','05 14 74 46 06'),(33,'Isabelle','Masson','henri71@bouygtel.fr','[\"ROLE_USER\"]','$2y$13$tiDKAupu4Wz53ogvNpapsOsEgHLuNbQn5Ra0b1XjP4dgj/8/awlwq','0139553456'),(34,'Nicolas','Mathieu','millet.julie@free.fr','[\"ROLE_USER\"]','$2y$13$uE5BppRFN/GsKySnEzqamOiP0baZKDPIqOuuxm2JBISAAV4h1WEAC','01 50 34 49 73'),(35,'Antoine','Gregoire','prevost.josephine@noos.fr','[\"ROLE_USER\"]','$2y$13$gz8RPrXC6bxY.Dul9lEpve1Yu3f51g1pFqn0XUyKDksdNVg4RnI3K','0470405976'),(36,'Guillaume','Blondel','denise.costa@bourdon.com','[\"ROLE_USER\"]','$2y$13$Aj4NVnRDu1gpsOBcnn8JWOPDvHY5rOJotwb6zwHXdOLAgvX3QfGyq','+33 7 65 65 74 73'),(37,'Élisabeth','Rey','techer.dominique@laposte.net','[\"ROLE_USER\"]','$2y$13$wAuOlS30o6icqNIrCDg6xeCtfV5bnkEAgguq7wPkCDUBJmshSpulW','0511257210'),(38,'Christiane','Carre','timothee37@bouygtel.fr','[\"ROLE_USER\"]','$2y$13$xc71z8Qmg26/o6DE7fl/JONHsTiMCPaH18uVEkVSO4uBOtY7FoANq','+33 8 96 23 09 72'),(39,'Catherine','Guichard','marianne86@lamy.net','[\"ROLE_USER\"]','$2y$13$YMQud7zUg9m3hWoFkSkT4uvdUUk.hyCKxI.Gwtab8Qb17v9/FtnjC','0549250610'),(40,'Alexandrie','Besnard','wagner.eric@clement.com','[\"ROLE_USER\"]','$2y$13$aWoxG.KEBLHsPy0ZFEucN.nFutuNzviCIfpRYqZTv7tArQCiNANo.','+33 2 75 80 26 82'),(41,'Julie','Hamon','juliette52@henry.fr','[\"ROLE_USER\"]','$2y$13$o5dzczSsdcRcZ7DsNW6yp.lGCg5LpNcS4KcLX7SR8utkHbPnUqNK6','09 02 79 07 95'),(42,'Gilles','Lesage','fpasquier@potier.com','[\"ROLE_USER\"]','$2y$13$nKgFHgbBCyv7q7p/A7ZSnuFTGw8UMtCiAZw3M/EqBbjbtIdz5Mf..','0729537178'),(43,'Henri','Gilles','blaroche@tele2.fr','[\"ROLE_USER\"]','$2y$13$qqOxSsCmz/Izyus5L0pKk.GyunS13TRVM8HXY6/UixjuSve4cGJNq','+33 (0)8 83 71 66 69'),(44,'Jacques','Begue','guy99@free.fr','[\"ROLE_USER\"]','$2y$13$T.oqCP01EL.IqFEo1aQa..f2p9.rUaIvCw4C0vG3yLKxlNk9skk/O','09 07 06 19 30'),(45,'Inès','Buisson','helene69@live.com','[\"ROLE_USER\"]','$2y$13$8ichr4hBTjxPMDrw5M//0exCOn3RMRnKYsXGX3h4OBoMPu04OL/n.','+33 3 86 96 10 52'),(46,'Madeleine','Hebert','gaillard.christine@dijoux.org','[\"ROLE_USER\"]','$2y$13$qzBuTCifqc.nNqZIYZ4t0.amouMvFWCi6aqujbXt0KCXdB1NRQ/jW','08 58 04 94 98'),(47,'Joséphine','Bernard','pdubois@bouygtel.fr','[\"ROLE_USER\"]','$2y$13$XIrXo2WagKKWQ4tVxyIngOcrBVJflg6zHRHxsF4aQ9WKEyg6QJbQe','+33 1 29 71 53 55'),(48,'Nathalie','Barbe','hugues76@live.com','[\"ROLE_USER\"]','$2y$13$8V3CS/v/m5KMrpju1pnSheKh4shgAkwAD0Xwx6DsNi0WYDHtC6a.K','+33 (0)2 80 37 15 84'),(49,'Thierry','Leclercq','christiane.bourgeois@mary.fr','[\"ROLE_USER\"]','$2y$13$KhkvyWkoUtgp/A1Kg4tCv./3lVVbtXb4e7Sl0dvTcW29QE1cstWgC','+33 (0)8 28 91 78 96'),(50,'Marguerite','Dubois','idelaunay@delorme.com','[\"ROLE_USER\"]','$2y$13$iEY.dn6X4z8Xr.BukcM0cu5qKOI0kyStHck60/44AgvvJXIYbsEm.','0543339016'),(51,'Maggie','Auger','vincent.giraud@leleu.com','[\"ROLE_USER\"]','$2y$13$3Y4m0/BpfWnvrb8VlBosbuCisQp4SV4M5JG1CGv1z6cGe2JrZboUG','07 49 98 39 63'),(52,'Simone','Laurent','benjamin55@menard.com','[\"ROLE_USER\"]','$2y$13$QgXnPjXAuW.5AzcC3bZwU.hwmmFYF1RLXomAB4i/4G/ejjE5MQSAG','01 53 76 82 92'),(53,'Nath','Besson','jacquet.bernadette@tanguy.com','[\"ROLE_USER\"]','$2y$13$NNa.ERmPgQfocZnqXGaDqOXJ.j1PtsZonTlb/rasTRXj9X8SQF.7e','+33 (0)2 25 65 50 64'),(54,'Catherine','Besson','payet.julie@orange.fr','[\"ROLE_USER\"]','$2y$13$dfCGWdz385RWwkRx8QeiLOYMYEXmzjsSAjsb2Icgp5Bqq.lz3716a','+33 8 11 20 02 71'),(55,'Josette','Masse','arnaude31@live.com','[\"ROLE_USER\"]','$2y$13$Jf4PAZaUqdBHOqAdsIx.dODBtvqc5yDkPKTFE9FOKY0XkXf2FfFu.','0900531443'),(56,'Nicole','Pinto','andre.benoit@free.fr','[\"ROLE_USER\"]','$2y$13$evoK30IJDXFbDUnBNlNXnu7ICxVSPXFRAKUQjSYmaaZqukR7aWRK6','+33 1 44 99 32 68'),(57,'Thomas','Chevallier','pjoly@gautier.com','[\"ROLE_USER\"]','$2y$13$SbRI2LNUGiXVjEFdlq79e.OQ1yv0M.VcTmSgHQQDHhodXnI/UfmLm','0781731964'),(58,'Bernadette','Ledoux','pclement@andre.com','[\"ROLE_USER\"]','$2y$13$jDSwiBVYdzaog2KAsdzIT.8P9A1wb/5pyzT/dNEe4AJAEvpW4sXDq','+33 (0)8 18 75 17 87'),(59,'Guillaume','Mallet','paul.teixeira@rolland.net','[\"ROLE_USER\"]','$2y$13$HoEYgefkZ5jLmUvpXATpkeXPu5ZIKsWmn0/cT9JdZ3mcGbw21OPNC','02 96 74 67 14'),(60,'Christine','Pereira','jeanne17@tele2.fr','[\"ROLE_USER\"]','$2y$13$lOab9j3blGUCubdY88vZY.oY8vOtwU4TMH2HHk9oQX1cMdmYDclLe','+33 4 90 14 68 19'),(61,'Thierry','Riviere','hortense26@orange.fr','[\"ROLE_USER\"]','$2y$13$Zl4UXuImz0Jr.hdipYZVw.ieiBsGgLueifmdczqD.4AuzJ88Mjqmm','0267299815'),(62,'Timothée','Fouquet','henriette.richard@laposte.net','[\"ROLE_OWNER\"]','$2y$13$/GKx07nGF3kaYvagoygpXefEnpgZGXTKY19/bkhSHZFAr5.wiGMf.','03 78 27 05 99'),(63,'Marianne','Le Goff','leroy.bernard@sfr.fr','[\"ROLE_OWNER\"]','$2y$13$mpAHjOUSl3gIapk9nfSxP.biXC8DJXo/AGailBFB/5FBDOws6NhLi','01 56 68 37 58'),(64,'Marianne','Fournier','valerie92@legendre.com','[\"ROLE_OWNER\"]','$2y$13$e0hZJ9BV0pi03UyW1MlzFuYZTVJfzaR9zm6wTnTpmanAr9PTOwaSC','+33 3 17 06 42 89'),(65,'Élise','Lejeune','marcelle.delahaye@dbmail.com','[\"ROLE_OWNER\"]','$2y$13$PSK0gH/FEZv9CItpV1M70OpOpXx.IdeVEpMRVcOqgOOiMUDQhq1hu','+33 2 40 83 16 81'),(66,'Michelle','Lemaitre','pierre21@michel.com','[\"ROLE_OWNER\"]','$2y$13$eZMGrHjWiRtTz2Sz85W6w.Hd44s83Xypz9E6J.69OldiMcfpXTPWi','+33 (0)4 47 65 47 84'),(67,'Bertrand','Chevallier','hloiseau@club-internet.fr','[\"ROLE_OWNER\"]','$2y$13$h7LZS9uPCZ3CaqKx46YnUe9Tx30666JOvYnjM8ekO/ASu6iqfX4HG','02 14 65 31 67'),(68,'Marcel','Herve','alix.aubert@yahoo.fr','[\"ROLE_OWNER\"]','$2y$13$2xrxotbB/LnTO72YsWYwoe6NKaYnryJnZ0tiLPaZsRrN18QFbQN9m','+33 (0)6 45 25 59 60'),(69,'Joseph','Couturier','dupre.aurore@gmail.com','[\"ROLE_OWNER\"]','$2y$13$s6EZwRUsZxBT3jtf67rJLOhten.56p.4BEmdx.bkVYyGl4zIVxJTW','+33 (0)1 67 30 99 06'),(70,'Christiane','Rousset','dominique76@chauveau.org','[\"ROLE_OWNER\"]','$2y$13$QqntaYT0fE803CmhlWtNdONNIL4hGhykGQfLkynSf9m11bx0XCbd2','+33 5 40 04 75 25'),(71,'Suzanne','Fontaine','fontaine.jules@bouygtel.fr','[\"ROLE_OWNER\"]','$2y$13$Ot41qF6LN1cAiSyuMAyfmOjec5pJha1tHMMJhwvqq5vTCzyR5/ywS','01 13 86 79 27'),(72,'Nicolas','Brunet','auguste75@hotmail.fr','[\"ROLE_OWNER\"]','$2y$13$buF1PBvuU88afag5KWYq8eAUueONKo0giiyn4ZGQ2DJjECkNc.CSq','+33 2 60 61 85 63'),(73,'Daniel','Besnard','lorraine.martineau@free.fr','[\"ROLE_OWNER\"]','$2y$13$Dnttf6SfUhTTfbq5jAcSI.37Yh/Y3uvjt8mpFVIhwHhArM.i4wY9K','+33 (0)3 87 02 69 87'),(74,'Diane','Legros','jrenault@foucher.fr','[\"ROLE_OWNER\"]','$2y$13$xIW/M12y/kQ0nJ6eNAm.KOjEdf3f6R/g9QEvg4viqQEOeLeUV/n.K','0944598789'),(75,'Éléonore','Brunel','masse.chantal@bonnin.net','[\"ROLE_OWNER\"]','$2y$13$uCSRJvaT2lVRwVSWNs9n0Oe6dCO.aIRzJVBcM5rpUcptLFtEiRn2W','+33 (0)7 80 56 38 36'),(76,'Guillaume','Dias','gmorvan@besson.com','[\"ROLE_OWNER\"]','$2y$13$0eKMNY/g.Qmb7pYzru357.Ca1WFWpHiJI8ju4fYd8gdLO1ATs6PsC','02 46 80 06 06'),(77,'Pierre','Thibault','lucas.gauthier@laposte.net','[\"ROLE_OWNER\"]','$2y$13$GOntcDD.uGE34QFFFQ/HX.Uz.jhoVtsNNf4k5pM7S04MypWVBNkpK','0503270749'),(78,'Patrick','Blanc','legros.therese@ifrance.com','[\"ROLE_OWNER\"]','$2y$13$ClIDy6TQoR/oqv1zbomJ3uGNzpWgUoCphwGzbMF7ej0hwV/wwZiVy','+33 (0)2 19 71 83 20'),(79,'Daniel','Laine','marty.joseph@bouygtel.fr','[\"ROLE_OWNER\"]','$2y$13$Z.05GIsh6.RE2jC958UD0OyEEU0UH0RH8NbyXqrZ6LdjNkfYxmGOG','+33 7 61 26 55 46'),(80,'Arthur','Lacroix','gdevaux@guillon.com','[\"ROLE_OWNER\"]','$2y$13$E5.bVMTlNqpGFCcJpNPaIOhwtipkOUQUj85Tm8ZUKe.CtxouXeNV2','05 71 85 81 97'),(81,'Anaïs','Blanchet','galves@olivier.com','[\"ROLE_OWNER\"]','$2y$13$rYXzOmzGyOa0q9n3BuM.ueIoUP2wzd.YCtlev5I7Ed5CvYMm5VCNu','+33 7 24 26 01 23'),(82,'Michèle','Noel','bcordier@bouygtel.fr','[\"ROLE_OWNER\"]','$2y$13$Yowitr859igNt90bRr1youe08ZaA5bHyLTIHa.shSYJ9msbZETUpm','+33 6 48 29 16 90'),(83,'Charles','Breton','knormand@bouygtel.fr','[\"ROLE_OWNER\"]','$2y$13$b9Ic0LMJpVcvSZEiPOVVt.n0VYhtTHTN1v.YQMbCjR6uBFoh1MioG','0254443281'),(84,'Camille','Masson','patricia55@boyer.com','[\"ROLE_OWNER\"]','$2y$13$1sZEcaLzI9rFcLY.MtsmZ.LN4CP4SmzOQ.bmxdV6jOborXy7YOTnm','+33 (0)2 09 38 52 50'),(85,'Zoé','Joubert','fdupuis@lacroix.fr','[\"ROLE_OWNER\"]','$2y$13$uDV/4wrpjfiClNG/Y.NSTeMeFmfLZrqEwSzjlQhaKlANvBCYz9ene','+33 1 46 16 25 68'),(86,'Pénélope','Lebon','lagarde.william@lebrun.net','[\"ROLE_OWNER\"]','$2y$13$Wcte7Xyiil5BcRhtDlz5DuhV6IfykQLFvYbpIHdh/NVJtZFZKWKnC','+33 (0)9 68 08 68 61'),(87,'Nathalie','Colas','cohen.suzanne@bodin.net','[\"ROLE_OWNER\"]','$2y$13$ZS4t91kGXSLmlIFADWOs6O1pVFMLEbcAbwaRHKGtLj8I8UrSf4hrm','08 12 48 73 80'),(88,'Grégoire','David','bernard.voisin@legendre.fr','[\"ROLE_OWNER\"]','$2y$13$C2nzsYvSSQvtKWNwVFPZL.j6pJkVAgep7T3BkQTfrXwglRXnhRgnC','+33 8 63 32 22 14'),(89,'Bernadette','Guerin','tribeiro@gmail.com','[\"ROLE_OWNER\"]','$2y$13$xtwkUY1pM.Y8FkLAXWoqguOLhEalgbUTkYFlxwvnPCvLA8bRn6iFS','+33 1 77 19 17 01'),(90,'Claire','Roger','lparent@voila.fr','[\"ROLE_OWNER\"]','$2y$13$2ccAmOY2FSM7FFu6jVF4YeuwdjxY1kX7CatcoYtre1AWTVzQW63QS','+33 9 75 30 96 07'),(91,'Pauline','Boutin','emilie.delmas@joseph.net','[\"ROLE_OWNER\"]','$2y$13$ctwVhZw4EkdeDWEXcaFq0OKsvN9bvmLEupnMOH5R4NwoonomuYcVy','+33 (0)6 47 39 51 34');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-12 20:26:05
